
#define N 3

int main(){
    char participants[N][32]= {"Papas Giorgos", "Nikolaou Petros", "Tzelou Anna"};
    int submissionIds[N][3]={
        {2, 0, 0},
        {11, 22, 0},
        {7, 0, 0}
    };



    return 0;
}
